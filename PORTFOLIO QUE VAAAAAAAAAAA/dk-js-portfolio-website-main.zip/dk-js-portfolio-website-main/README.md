# dk-js-portfolio-website
### [Live Site](https://dk-js-portfolio-website.vercel.app/)

https://user-images.githubusercontent.com/30509335/229765023-376c0127-713b-43f0-95dc-1acbe28a86a5.mov

## About
* 👋 Hi, I’m Chidike Henry 
* 😎 I’m a web developer 
* 💻 This is a personal portfolio website made with HTML, CSS and JS.
* 🌍 Website:  https://dk-js-portfolio-website.vercel.app/
* 💞️ I’m looking to collaborate on JS projects 
* 📫 How to reach me chidike.henry@gmail.com


## Technologies Used
* CSS
* HTML
* GitHub
* JavaScript

## Author

#### 👤 Author1
- GitHub: [@lacegiovanni17]https://github.com/lacegiovanni17
- Twitter: [@ChidikeC] https://twitter.com/ChidikeC
- LinkedIn: [LinkedIn]https://www.linkedin.com/in/chidike-chizoba-25628a40/

## Contributing 
Contributions, issues, and feature requests are welcome!

## Show your support
Please give a ⭐️ if you like this project! 

## Acknowledgments
- Hat tip to anyone contributed one way or the other.
- Inspiration
- etc
